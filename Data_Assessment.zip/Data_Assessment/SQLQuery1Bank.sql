-- Krijimi i databaz�s TBU_DWH
CREATE DATABASE TBU_DWH1;
GO

-- P�rdorimi i databaz�s s� re
USE TBU_DWH1;
GO

-- Krijimi i skem�s RAW_DATA
CREATE SCHEMA RAW_DATA;
GO

-- Krijimi i skem�s DW_DATA
CREATE SCHEMA DW_DATA;
GO
-- Krijimi i tabel�s Customers
CREATE TABLE RAW_DATA.Customers (
    CustomerID INT PRIMARY KEY,
    CustomerName VARCHAR(255),
    CustomerAddress VARCHAR(255),
    StartDate DATE
);
GO

-- Krijimi i tabel�s Accounts
CREATE TABLE RAW_DATA.Accounts (
    AccountID INT PRIMARY KEY,
    CustomerID INT,
    AccountType VARCHAR(25),
    AccountStatus VARCHAR(25),
    OpeningDate DATE,
    FOREIGN KEY (CustomerID) REFERENCES RAW_DATA.Customers(CustomerID)
);
GO
-- Krijimi i tabel�s Transactions
CREATE TABLE RAW_DATA.Transactions (
    TransactionID INT PRIMARY KEY,
    AccountID INT,
    TransactionAmount FLOAT,
    TransactionDate DATE,
    CONSTRAINT FK_Transactions_Accounts FOREIGN KEY (AccountID) REFERENCES RAW_DATA.Accounts(AccountID)
);
GO
-- Krijimi i tabel�s CustomerDemography
CREATE TABLE RAW_DATA.CustomerDemography (
    CustomerID INT PRIMARY KEY,
    DateOfBirth DATE,
    City VARCHAR(25),
    CONSTRAINT FK_CustomerDemography_Customers FOREIGN KEY (CustomerID) REFERENCES RAW_DATA.Customers(CustomerID)
);
GO


-- Kontrollimi i  t� dh�nave n� tabelat e transferuara
SELECT * FROM RAW_DATA.Transactions;
SELECT * FROM RAW_DATA.Accounts;
SELECT * FROM RAW_DATA.Customers;
SELECT * FROM RAW_DATA.CustomerDemography;


USE TBU_DWH1;
GO
-- Krijimi i tabel�s Dim_Customers
CREATE TABLE DW_DATA.Dim_Customers (
    ID INT IDENTITY(1,1) PRIMARY KEY,
    CustomerID INT,
    CustomerName VARCHAR(255),
    CustomerAddress VARCHAR(255),
    StartDate DATE,
    TimeWithBank FLOAT,
    DateOfBirth DATE,
    Age INT,
    City VARCHAR(25)
);

-- Krijo tabel�n Dim_Accounts
CREATE TABLE DW_DATA.Dim_Accounts (
    ID INT IDENTITY(1,1) PRIMARY KEY,
    AccountID INT,
    Customer_FK INT FOREIGN KEY REFERENCES DW_DATA.Dim_Customers(ID),
    AccountType VARCHAR(25),
    AccountStatus VARCHAR(25),
    OpeningDate DATE
);

-- Krijo tabel�n Fct_Transactions
CREATE TABLE DW_DATA.Fct_Transactions (
    ID INT IDENTITY(1,1) PRIMARY KEY,
    TransactionID INT,
    Accounts_FK INT FOREIGN KEY REFERENCES DW_DATA.Dim_Accounts(ID),
    Customer_FK INT FOREIGN KEY REFERENCES DW_DATA.Dim_Customers(ID),
    TransactionAmount FLOAT,
    TransactionDate DATE,
    AccountingLedger VARCHAR(1)
);

-- Futen t� dh�nat n� tabel�n Dim_Customers nga tabelat RAW_DATA.Customers dhe RAW_DATA.CustomerDemography
INSERT INTO DW_DATA.Dim_Customers (CustomerID, CustomerName, CustomerAddress, StartDate, TimeWithBank, DateOfBirth, Age, City)
SELECT 
    C.CustomerID,
    C.CustomerName,
    C.CustomerAddress,
    C.StartDate,
    DATEDIFF(MONTH, C.StartDate, GETDATE()) AS TimeWithBank,
    CD.DateOfBirth,
    DATEDIFF(YEAR, CD.DateOfBirth, GETDATE()) AS Age,
    CD.City
FROM 
    RAW_DATA.Customers C
JOIN 
    RAW_DATA.CustomerDemography CD ON C.CustomerID = CD.CustomerID;

SELECT COUNT(*) AS NumriRreshtave
FROM DW_DATA.Dim_Customers;
GO


-- Fut t� dh�na n� tabel�n Dim_Accounts nga tabelat RAW_DATA.Accounts dhe DW_DATA.Dim_Customers
INSERT INTO DW_DATA.Dim_Accounts (AccountID, Customer_FK, AccountType, AccountStatus, OpeningDate)
SELECT
    A.AccountID,
    DC.ID AS Customer_FK,
    A.AccountType,
    A.AccountStatus,
    A.OpeningDate
FROM RAW_DATA.Accounts A
JOIN DW_DATA.Dim_Customers DC ON A.CustomerID = DC.CustomerID;


-- Fut t� dh�na n� tabel�n Fct_Transactions nga tabelat RAW_DATA.Transactions, DW_DATA.Dim_Accounts dhe DW_DATA.Dim_Customers
INSERT INTO DW_DATA.Fct_Transactions (TransactionID, Accounts_FK, Customer_FK, TransactionAmount, TransactionDate, AccountingLedger)
SELECT
    T.TransactionID,
    DA.ID AS Accounts_FK,
    DC.ID AS Customer_FK,
    T.TransactionAmount,
    T.TransactionDate,
    CASE WHEN T.TransactionAmount < 0 THEN 'D' ELSE 'C' END AS AccountingLedger
FROM RAW_DATA.Transactions T
JOIN DW_DATA.Dim_Accounts DA ON T.AccountID = DA.AccountID
JOIN DW_DATA.Dim_Customers DC ON CustomerID = DC.CustomerID;


-- Num�ron transaksionet p�r klient�t e mosh�s 30-40 vje� gjat� vitit 2024
SELECT COUNT (*) AS NumriTransaksioneve
FROM DW_DATA.Fct_Transactions FT
JOIN DW_DATA.Dim_Customers DC ON FT.Customer_FK = DC.ID
WHERE DC.Age BETWEEN 30 AND 40
  AND YEAR(FT.TransactionDate) = 2024;
GO

-- Merr 5 klient�t me m� shum� transaksione dhe i r�ndit ata n� m�nyr� zbrit�se sipas numrit t� transaksioneve
 SELECT TOP 5 DC.CustomerID, DC.CustomerName, COUNT(FT.TransactionID) AS NumriTransaksioneve
FROM DW_DATA.Fct_Transactions FT
JOIN DW_DATA.Dim_Customers DC ON FT.Customer_FK = DC.ID
GROUP BY DC.CustomerID, DC.CustomerName
ORDER BY COUNT(FT.TransactionID) DESC;

--Vlerat mesatare te kreditimeve dhe debitimeve ne llogari pergjate historikut (Fct_Transactions.AccountingLedger = �C� >> Kreditime, Fct_Transactions.AccountingLedger = �D� >> Debitime)

SELECT
    F.AccountingLedger AS LlojiTransaksionit,
    AVG(F.TransactionAmount) AS Mesatarja
FROM
    DW_DATA.Fct_Transactions F
GROUP BY
    F.AccountingLedger;


-- Numri i veprimeve dhe shumat e transaksioneve p�r klient�t e hapur n� muajin Janar 2020 p�r periudh�n 2022-2023
SELECT 
    dc.CustomerName,
    COUNT(*) AS NumTransactions,
    SUM(ft.TransactionAmount) AS TotalTransactionAmount
FROM TBU_DWH1.DW_DATA.Fct_Transactions ft
JOIN TBU_DWH1.DW_DATA.Dim_Customers dc ON ft.Customer_FK = dc.ID
JOIN TBU_DWH1.DW_DATA.Dim_Accounts da ON ft.Accounts_FK = da.ID
WHERE YEAR(dc.StartDate) = 2020 AND MONTH(dc.StartDate) = 1
  AND YEAR(ft.TransactionDate) BETWEEN 2022 AND 2023
GROUP BY dc.CustomerName;


